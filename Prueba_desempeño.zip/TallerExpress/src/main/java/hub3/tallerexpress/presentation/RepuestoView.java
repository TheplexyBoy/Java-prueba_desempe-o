/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.RepuestoController;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.util.TablaHelper;
import hub3.tallerexpress.util.VentanaUtil;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class RepuestoView {

    private final RepuestoController repuestoController;

    public RepuestoView(RepuestoController repuestoController) {
        this.repuestoController = repuestoController;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"Registrar", "Editar", "Activar/Desactivar", "Listar", "Filtrar", "Volver"};
            int seleccion = JOptionPane.showOptionDialog(null, "Gestión de Repuestos", "Repuestos",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion == -1) return;

            switch (opciones[seleccion]) {
                case "Registrar" -> registrar();
                case "Editar" -> editar();
                case "Activar/Desactivar" -> cambiarEstado();
                case "Listar" -> listar();
                case "Filtrar" -> filtrar();
                case "Volver" -> volver = true;
            }
        }
    }

    private void registrar() {
        try {
            String codigo = JOptionPane.showInputDialog("Código de referencia:");
            if (codigo == null) return;
            String nombre = JOptionPane.showInputDialog("Nombre:");
            String categoria = JOptionPane.showInputDialog("Categoría:");
            String proveedor = JOptionPane.showInputDialog("Proveedor:");
            int stockTotal = Integer.parseInt(JOptionPane.showInputDialog("Stock total:"));
            double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio unitario:"));

            Repuesto r = new Repuesto();
            r.setCodigoReferencia(codigo);
            r.setNombre(nombre);
            r.setCategoria(categoria);
            r.setProveedor(proveedor);
            r.setStockTotal(stockTotal);
            r.setStockDisponible(stockTotal);
            r.setPrecioUnitario(precio);

            repuestoController.registrar(r);
            JOptionPane.showMessageDialog(null, "Repuesto registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Stock y precio deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editar() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del repuesto a editar:"));
            Repuesto r = repuestoController.buscarPorId(id);
            if (r == null) {
                JOptionPane.showMessageDialog(null, "No existe un repuesto con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            r.setNombre(JOptionPane.showInputDialog("Nombre:", r.getNombre()));
            r.setCategoria(JOptionPane.showInputDialog("Categoría:", r.getCategoria()));
            r.setProveedor(JOptionPane.showInputDialog("Proveedor:", r.getProveedor()));
            r.setStockTotal(Integer.parseInt(JOptionPane.showInputDialog("Stock total:", r.getStockTotal())));
            r.setStockDisponible(Integer.parseInt(JOptionPane.showInputDialog("Stock disponible:", r.getStockDisponible())));
            r.setPrecioUnitario(Double.parseDouble(JOptionPane.showInputDialog("Precio unitario:", r.getPrecioUnitario())));

            repuestoController.actualizar(r);
            JOptionPane.showMessageDialog(null, "Repuesto actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Datos numéricos inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cambiarEstado() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del repuesto:"));
            int opcion = JOptionPane.showConfirmDialog(null, "¿Activar este repuesto? (No = desactivar)", "Cambiar estado", JOptionPane.YES_NO_CANCEL_OPTION);
            if (opcion == JOptionPane.CANCEL_OPTION || opcion == JOptionPane.CLOSED_OPTION) return;
            repuestoController.cambiarEstado(id, opcion == JOptionPane.YES_OPTION);
            JOptionPane.showMessageDialog(null, "Estado actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listar() {
        List<Repuesto> lista = repuestoController.listarTodos();
        VentanaUtil.mostrarTabla("Listado de Repuestos", TablaHelper.tablaRepuestos(lista));
    }

    private void filtrar() {
        String categoria = JOptionPane.showInputDialog("Categoría (vacío para omitir):");
        String proveedor = JOptionPane.showInputDialog("Proveedor (vacío para omitir):");
        List<Repuesto> lista = repuestoController.filtrar(categoria, proveedor);
        VentanaUtil.mostrarTabla("Repuestos filtrados", TablaHelper.tablaRepuestos(lista));
    }
}