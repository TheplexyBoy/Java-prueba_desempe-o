/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.ClienteController;
import hub3.tallerexpress.controller.VehiculoController;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.model.Vehiculo;
import hub3.tallerexpress.util.TablaHelper;
import hub3.tallerexpress.util.VentanaUtil;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class VehiculoView {

    private final VehiculoController vehiculoController;
    private final ClienteController clienteController;

    public VehiculoView(VehiculoController vehiculoController, ClienteController clienteController) {
        this.vehiculoController = vehiculoController;
        this.clienteController = clienteController;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"Registrar", "Listar todos", "Ver por cliente", "Volver"};
            int seleccion = JOptionPane.showOptionDialog(null, "Gestión de Vehículos", "Vehículos",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion == -1) return;

            switch (opciones[seleccion]) {
                case "Registrar" -> registrar();
                case "Listar todos" -> listarTodos();
                case "Ver por cliente" -> listarPorCliente();
                case "Volver" -> volver = true;
            }
        }
    }

    private void registrar() {
        try {
            int clienteId = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente dueño:"));
            Cliente cliente = clienteController.buscarPorId(clienteId);
            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "No existe un cliente con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String placa = JOptionPane.showInputDialog("Placa:");
            String marca = JOptionPane.showInputDialog("Marca:");
            String modelo = JOptionPane.showInputDialog("Modelo:");
            int anio = Integer.parseInt(JOptionPane.showInputDialog("Año:"));

            Vehiculo v = new Vehiculo();
            v.setCliente(cliente);
            v.setPlaca(placa);
            v.setMarca(marca);
            v.setModelo(modelo);
            v.setAnio(anio);

            vehiculoController.registrar(v);
            JOptionPane.showMessageDialog(null, "Vehículo registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID y año deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listarTodos() {
        List<Vehiculo> lista = vehiculoController.listarTodos();
        VentanaUtil.mostrarTabla("Listado de Vehículos", TablaHelper.tablaVehiculos(lista));
    }

    private void listarPorCliente() {
        try {
            int clienteId = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente:"));
            List<Vehiculo> lista = vehiculoController.listarPorCliente(clienteId);
            VentanaUtil.mostrarTabla("Vehículos del cliente", TablaHelper.tablaVehiculos(lista));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}