/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.UsuarioController;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.util.TablaHelper;
import hub3.tallerexpress.util.VentanaUtil;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class UsuarioView {

    private final UsuarioController usuarioController;

    public UsuarioView(UsuarioController usuarioController) {
        this.usuarioController = usuarioController;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"Registrar", "Editar", "Activar/Desactivar", "Listar", "Volver"};
            int seleccion = JOptionPane.showOptionDialog(null, "Gestión de Usuarios", "Usuarios",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion == -1) return;

            switch (opciones[seleccion]) {
                case "Registrar" -> registrar();
                case "Editar" -> editar();
                case "Activar/Desactivar" -> cambiarEstado();
                case "Listar" -> listar();
                case "Volver" -> volver = true;
            }
        }
    }

    private void registrar() {
        try {
            String username = JOptionPane.showInputDialog("Username:");
            if (username == null) return;
            String password = JOptionPane.showInputDialog("Contraseña:");
            String nombreCompleto = JOptionPane.showInputDialog("Nombre completo:");
            String[] roles = {"ADMIN", "RECEPCIONISTA"};
            int seleccion = JOptionPane.showOptionDialog(null, "Rol:", "Rol",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, roles, roles[1]);

            Usuario u = new Usuario();
            u.setUsername(username);
            u.setPassword(password);
            u.setNombreCompleto(nombreCompleto);
            if (seleccion != -1) {
                u.setRol(roles[seleccion]);
            }
            // si no elige rol, el decorador (CreadorUsuarioConValoresPorDefecto) le pone RECEPCIONISTA solo

            usuarioController.registrar(u);
            JOptionPane.showMessageDialog(null, "Usuario registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editar() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del usuario a editar:"));
            Usuario u = usuarioController.buscarPorId(id);
            if (u == null) {
                JOptionPane.showMessageDialog(null, "No existe un usuario con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            u.setNombreCompleto(JOptionPane.showInputDialog("Nombre completo:", u.getNombreCompleto()));
            String[] roles = {"ADMIN", "RECEPCIONISTA"};
            int seleccion = JOptionPane.showOptionDialog(null, "Rol:", "Rol",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, roles,
                    "ADMIN".equals(u.getRol()) ? roles[0] : roles[1]);
            if (seleccion != -1) {
                u.setRol(roles[seleccion]);
            }

            usuarioController.actualizar(u);
            JOptionPane.showMessageDialog(null, "Usuario actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cambiarEstado() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del usuario:"));
            int opcion = JOptionPane.showConfirmDialog(null, "¿Activar este usuario? (No = desactivar)", "Cambiar estado", JOptionPane.YES_NO_CANCEL_OPTION);
            if (opcion == JOptionPane.CANCEL_OPTION || opcion == JOptionPane.CLOSED_OPTION) return;
            usuarioController.cambiarEstado(id, opcion == JOptionPane.YES_OPTION);
            JOptionPane.showMessageDialog(null, "Estado actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listar() {
        List<Usuario> lista = usuarioController.listar();
        VentanaUtil.mostrarTabla("Listado de Usuarios", TablaHelper.tablaUsuarios(lista));
    }
}