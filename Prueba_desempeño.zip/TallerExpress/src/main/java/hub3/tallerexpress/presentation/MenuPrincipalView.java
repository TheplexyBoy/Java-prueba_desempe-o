/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.ClienteController;
import hub3.tallerexpress.controller.OrdenController;
import hub3.tallerexpress.controller.RepuestoController;
import hub3.tallerexpress.controller.UsuarioController;
import hub3.tallerexpress.controller.VehiculoController;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class MenuPrincipalView {

    private final UsuarioController usuarioController;
    private final ClienteController clienteController = new ClienteController();
    private final VehiculoController vehiculoController = new VehiculoController();
    private final RepuestoController repuestoController = new RepuestoController();
    private final OrdenController ordenController = new OrdenController();

    public MenuPrincipalView(UsuarioController usuarioController) {
        this.usuarioController = usuarioController;
    }

    public void mostrar() {
        boolean salir = false;
        while (!salir) {
            String[] opcionesAdmin = {"Repuestos", "Clientes", "Vehículos", "Usuarios", "Órdenes de Servicio", "Salir"};
            String[] opcionesRecepcionista = {"Repuestos", "Clientes", "Vehículos", "Órdenes de Servicio", "Salir"};
            String[] opciones = usuarioController.esAdmin() ? opcionesAdmin : opcionesRecepcionista;

            String nombre = usuarioController.getUsuarioEnSesion().getNombreCompleto();
            int seleccion = JOptionPane.showOptionDialog(
                    null,
                    "Sesión: " + nombre + " (" + usuarioController.getUsuarioEnSesion().getRol() + ")",
                    "TallerExpress - Menú Principal",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]
            );

            if (seleccion == -1) {
                salir = true;
                continue;
            }

            switch (opciones[seleccion]) {
                case "Repuestos" -> new RepuestoView(repuestoController).mostrar();
                case "Clientes" -> new ClienteView(clienteController).mostrar();
                case "Vehículos" -> new VehiculoView(vehiculoController, clienteController).mostrar();
                case "Usuarios" -> new UsuarioView(usuarioController).mostrar();
                case "Órdenes de Servicio" -> new OrdenView(ordenController, vehiculoController, repuestoController).mostrar();
                case "Salir" -> salir = true;
            }
        }
    }
}