/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.ClienteController;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.util.TablaHelper;
import hub3.tallerexpress.util.VentanaUtil;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class ClienteView {

    private final ClienteController clienteController;

    public ClienteView(ClienteController clienteController) {
        this.clienteController = clienteController;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"Registrar", "Editar", "Activar/Desactivar", "Listar", "Volver"};
            int seleccion = JOptionPane.showOptionDialog(null, "Gestión de Clientes", "Clientes",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion == -1) return;

            switch (opciones[seleccion]) {
                case "Registrar" -> registrar();
                case "Editar" -> editar();
                case "Activar/Desactivar" -> cambiarEstado();
                case "Listar" -> listar();
                case "Volver" -> volver = true;
            }
        }
    }

    private void registrar() {
        try {
            String nombre = JOptionPane.showInputDialog("Nombre completo:");
            if (nombre == null) return;
            String documento = JOptionPane.showInputDialog("Documento:");
            String telefono = JOptionPane.showInputDialog("Teléfono:");
            String email = JOptionPane.showInputDialog("Email:");
            String direccion = JOptionPane.showInputDialog("Dirección:");

            Cliente c = new Cliente();
            c.setNombre(nombre);
            c.setDocumento(documento);
            c.setTelefono(telefono);
            c.setEmail(email);
            c.setDireccion(direccion);

            clienteController.registrar(c);
            JOptionPane.showMessageDialog(null, "Cliente registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editar() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente a editar:"));
            Cliente c = clienteController.buscarPorId(id);
            if (c == null) {
                JOptionPane.showMessageDialog(null, "No existe un cliente con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            c.setNombre(JOptionPane.showInputDialog("Nombre:", c.getNombre()));
            c.setTelefono(JOptionPane.showInputDialog("Teléfono:", c.getTelefono()));
            c.setEmail(JOptionPane.showInputDialog("Email:", c.getEmail()));
            c.setDireccion(JOptionPane.showInputDialog("Dirección:", c.getDireccion()));

            clienteController.actualizar(c);
            JOptionPane.showMessageDialog(null, "Cliente actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cambiarEstado() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID del cliente:"));
            int opcion = JOptionPane.showConfirmDialog(null, "¿Activar este cliente? (No = desactivar)", "Cambiar estado", JOptionPane.YES_NO_CANCEL_OPTION);
            if (opcion == JOptionPane.CANCEL_OPTION || opcion == JOptionPane.CLOSED_OPTION) return;
            clienteController.cambiarEstado(id, opcion == JOptionPane.YES_OPTION);
            JOptionPane.showMessageDialog(null, "Estado actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listar() {
        List<Cliente> lista = clienteController.listar();
        VentanaUtil.mostrarTabla("Listado de Clientes", TablaHelper.tablaClientes(lista));
    }
}