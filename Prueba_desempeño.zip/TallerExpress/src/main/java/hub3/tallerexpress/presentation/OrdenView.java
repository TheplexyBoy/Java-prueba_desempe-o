/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.OrdenController;
import hub3.tallerexpress.controller.RepuestoController;
import hub3.tallerexpress.controller.VehiculoController;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.DetalleOrden;
import hub3.tallerexpress.model.Orden;
import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.model.Vehiculo;
import hub3.tallerexpress.util.TablaHelper;
import hub3.tallerexpress.util.VentanaUtil;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class OrdenView {

    private final OrdenController ordenController;
    private final VehiculoController vehiculoController;
    private final RepuestoController repuestoController;

    public OrdenView(OrdenController ordenController, VehiculoController vehiculoController, RepuestoController repuestoController) {
        this.ordenController = ordenController;
        this.vehiculoController = vehiculoController;
        this.repuestoController = repuestoController;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"Registrar orden", "Actualizar estado", "Listar todas", "Historial por vehículo", "Volver"};
            int seleccion = JOptionPane.showOptionDialog(null, "Gestión de Órdenes de Servicio", "Órdenes",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
            if (seleccion == -1) {
                return;
            }

            switch (opciones[seleccion]) {
                case "Registrar orden" ->
                    registrar();
                case "Actualizar estado" ->
                    actualizarEstado();
                case "Listar todas" ->
                    listarTodas();
                case "Historial por vehículo" ->
                    historialPorVehiculo();
                case "Volver" ->
                    volver = true;
            }
        }
    }

    private void registrar() {
        try {
            int vehiculoId = Integer.parseInt(JOptionPane.showInputDialog("ID del vehículo:"));
            Vehiculo vehiculo = vehiculoController.buscarPorId(vehiculoId);
            if (vehiculo == null) {
                JOptionPane.showMessageDialog(null, "No existe un vehículo con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String mecanico = JOptionPane.showInputDialog("Mecánico responsable:");
            String descripcion = JOptionPane.showInputDialog("Descripción del problema:");
            String diagnostico = JOptionPane.showInputDialog("Diagnóstico:");

            Orden orden = new Orden();
            orden.setVehiculo(vehiculo);
            orden.setMecanico(mecanico);
            orden.setDescripcionProblema(descripcion);
            orden.setDiagnostico(diagnostico);

            boolean seguirAgregando = true;
            while (seguirAgregando) {
                String codigo = JOptionPane.showInputDialog("Código del repuesto a usar (Cancelar para terminar):");
                if (codigo == null) {
                    break;
                }
                Repuesto r = repuestoController.buscarPorCodigo(codigo);
                if (r == null) {
                    JOptionPane.showMessageDialog(null, "No existe un repuesto con ese código.", "Error", JOptionPane.ERROR_MESSAGE);
                    continue;
                }
                int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de \"" + r.getNombre() + "\":"));
                orden.agregarRepuesto(new DetalleOrden(0, r, cantidad, r.getPrecioUnitario()));

                int opcion = JOptionPane.showConfirmDialog(null, "¿Agregar otro repuesto?", "Repuestos", JOptionPane.YES_NO_OPTION);
                seguirAgregando = (opcion == JOptionPane.YES_OPTION);
            }

            ordenController.registrar(orden);
            JOptionPane.showMessageDialog(null, "Orden registrada. Total: $" + orden.getCostoTotal(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Datos numéricos inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarEstado() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("ID de la orden:"));
            String[] estados = {"RECIBIDA", "EN_DIAGNOSTICO", "EN_REPARACION", "FINALIZADA", "ENTREGADA"};
            int seleccion = JOptionPane.showOptionDialog(null, "Nuevo estado:", "Actualizar estado",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, estados, estados[0]);
            if (seleccion == -1) {
                return;
            }

            ordenController.actualizarEstado(id, estados[seleccion]);
            JOptionPane.showMessageDialog(null, "Estado actualizado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (ValidacionException | PersistenciaException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listarTodas() {
        List<Orden> lista = ordenController.listarTodas();
        VentanaUtil.mostrarTabla("Listado de Órdenes", TablaHelper.tablaOrdenes(lista));
    }

    private void historialPorVehiculo() {
        try {
            int vehiculoId = Integer.parseInt(JOptionPane.showInputDialog("ID del vehículo:"));
            List<Orden> lista = ordenController.listarPorVehiculo(vehiculoId);
            VentanaUtil.mostrarTabla("Historial de servicios", TablaHelper.tablaOrdenes(lista));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
