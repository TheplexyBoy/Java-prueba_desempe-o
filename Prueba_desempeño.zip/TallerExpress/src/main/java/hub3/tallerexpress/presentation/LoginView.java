/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.presentation;

import hub3.tallerexpress.controller.UsuarioController;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Usuario;
import javax.swing.JOptionPane;

/**
 *
 * @author coder
 */
public class LoginView {

    private final UsuarioController usuarioController;

    public LoginView(UsuarioController usuarioController) {
        this.usuarioController = usuarioController;
    }

    // Devuelve el usuario si el login fue exitoso, o null si el usuario cancelo
    public Usuario mostrar() {
        while (true) {
            String username = JOptionPane.showInputDialog(null, "Usuario:", "TallerExpress - Login", JOptionPane.PLAIN_MESSAGE);
            if (username == null) {
                return null; // el usuario le dio "Cancelar"
            }

            String password = JOptionPane.showInputDialog(null, "Contraseña:", "TallerExpress - Login", JOptionPane.PLAIN_MESSAGE);
            if (password == null) {
                return null;
            }

            try {
                Usuario usuario = usuarioController.login(username, password);
                JOptionPane.showMessageDialog(null, "¡Bienvenido, " + usuario.getNombreCompleto() + "!", "Acceso concedido", JOptionPane.INFORMATION_MESSAGE);
                return usuario;
            } catch (ValidacionException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error de acceso", JOptionPane.ERROR_MESSAGE);
                // vuelve a preguntar
            }
        }
    }
}