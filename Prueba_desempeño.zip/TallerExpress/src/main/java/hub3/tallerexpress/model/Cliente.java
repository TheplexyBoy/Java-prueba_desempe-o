/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class Cliente {

    private int id;
    private String nombre;
    private String documento;
    private String telefono;
    private String email;
    private String direccion;
    private boolean activo;
    private LocalDateTime createdAt;

    public Cliente() {
    }

    public Cliente(int id, String nombre, String documento, String telefono, String email, String direccion, boolean activo, LocalDateTime createdAt) {
        this.id = id;
        this.nombre = nombre;
        this.documento = documento;
        this.telefono = telefono;
        this.email = email;
        this.direccion = direccion;
        this.activo = activo;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getDireccion() {
        return direccion;
    }

    public boolean isActivo() {
        return activo;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        String mostrarNombre = (this.nombre != null && !this.nombre.trim().isEmpty()) ? this.nombre : "Cliente inexistente";
        String textoEstado = (this.activo) ? "Activo " : "Inactivo";
        return "Nombre: " + mostrarNombre + " | Estado: " + textoEstado;
    }
}
