/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class Repuesto {

    private int id;
    private String codigoReferencia;
    private String nombre;
    private String categoria;
    private String proveedor;
    private int stockTotal;
    private int stockDisponible;
    private double precioUnitario;
    private boolean isActivo;
    private LocalDateTime createdAt;

    public Repuesto() {
    }

    public Repuesto(int id, String codigoReferencia, String nombre, String categoria, String proveedor, int stockTotal, int stockDisponible, double precioUnitario, boolean isActivo, LocalDateTime createdAt) {
        this.id = id;
        this.codigoReferencia = codigoReferencia;
        this.nombre = nombre;
        this.categoria = categoria;
        this.proveedor = proveedor;
        this.stockTotal = stockTotal;
        this.stockDisponible = stockDisponible;
        this.precioUnitario = precioUnitario;
        this.isActivo = isActivo;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public String getCodigoReferencia() {
        return codigoReferencia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getProveedor() {
        return proveedor;
    }

    public int getStockTotal() {
        return stockTotal;
    }

    public int getStockDisponible() {
        return stockDisponible;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public boolean isIsActivo() {
        return isActivo;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCodigoReferencia(String codigoReferencia) {
        this.codigoReferencia = codigoReferencia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setStockTotal(int stockTotal) {
        this.stockTotal = stockTotal;
    }

    public void setStockDisponible(int stockDisponible) {
        this.stockDisponible = stockDisponible;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public void setIsActivo(boolean isActivo) {
        this.isActivo = isActivo;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        String mostrarRepuesto = (this.nombre != null && !this.nombre.trim().isEmpty()) ? this.nombre : "No existe";
        String textoEstado = (this.isActivo) ? "Activo " : "Inactivo";
        return "Repuesto: " + mostrarRepuesto + " | Estado: " + textoEstado;
    }
}
