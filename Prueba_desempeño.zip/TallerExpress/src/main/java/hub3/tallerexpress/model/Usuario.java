/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class Usuario {

    private int id;
    private String username;
    private String password;
    private String nombreCompleto;
    private String rol; // "ADMIN" o "RECEPCIONISTA"
    private boolean activo;
    private LocalDateTime createdAt;

    public Usuario() {
    }

    public Usuario(int id, String username, String password, String nombreCompleto, String rol, boolean activo, LocalDateTime createdAt) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.nombreCompleto = nombreCompleto;
        this.rol = rol;
        this.activo = activo;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getRol() {
        return rol;
    }

    public boolean isActivo() {
        return activo;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        String mostrarUsername = (this.username != null && !this.username.trim().isEmpty()) ? this.username : "Sin credenciales";
        String textoEstado = (this.activo) ? "Activo " : "Inactivo";
        return "Username: " + mostrarUsername + " | Rol: " + rol + " | Estado: " + textoEstado;
    }
}
