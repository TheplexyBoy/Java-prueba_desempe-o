/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

/**
 *
 * @author coder
 */
public class DetalleOrden {

    private int id;
    private Repuesto repuesto;
    private int cantidad;
    private double precioUnitario;

    public DetalleOrden() {
    }

    public DetalleOrden(int id, Repuesto repuesto, int cantidad, double precioUnitario) {
        this.id = id;
        this.repuesto = repuesto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public int getId() {
        return id;
    }

    public Repuesto getRepuesto() {
        return repuesto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRepuesto(Repuesto repuesto) {
        this.repuesto = repuesto;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotal() {
        return precioUnitario * cantidad;
    }

    @Override
    public String toString() {
        String nombreRepuesto = (repuesto != null) ? repuesto.getNombre() : "Repuesto desconocido";
        return nombreRepuesto + " x" + cantidad + " = $" + getSubtotal();
    }
}
