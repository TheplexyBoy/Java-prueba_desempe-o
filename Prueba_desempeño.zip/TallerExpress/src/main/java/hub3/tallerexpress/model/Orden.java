/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author coder
 */
public class Orden {

    private int id;
    private Vehiculo vehiculo; // el vehiculo ya trae el cliente adentro
    private String mecanico;
    private LocalDateTime fechaIngreso;
    private String descripcionProblema;
    private String diagnostico;
    private String estado; // RECIBIDA, EN_DIAGNOSTICO, EN_REPARACION, FINALIZADA, ENTREGADA
    private double costoTotal;
    private List<DetalleOrden> repuestosUtilizados;

    public Orden() {
        this.estado = "RECIBIDA";
        this.repuestosUtilizados = new ArrayList<>();
    }

    public Orden(int id, Vehiculo vehiculo, String mecanico, LocalDateTime fechaIngreso, String descripcionProblema, String diagnostico, String estado, double costoTotal) {
        this.id = id;
        this.vehiculo = vehiculo;
        this.mecanico = mecanico;
        this.fechaIngreso = fechaIngreso;
        this.descripcionProblema = descripcionProblema;
        this.diagnostico = diagnostico;
        this.estado = estado;
        this.costoTotal = costoTotal;
        this.repuestosUtilizados = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public String getMecanico() {
        return mecanico;
    }

    public LocalDateTime getFechaIngreso() {
        return fechaIngreso;
    }

    public String getDescripcionProblema() {
        return descripcionProblema;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getEstado() {
        return estado;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public List<DetalleOrden> getRepuestosUtilizados() {
        return repuestosUtilizados;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public void setMecanico(String mecanico) {
        this.mecanico = mecanico;
    }

    public void setFechaIngreso(LocalDateTime fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public void setDescripcionProblema(String descripcionProblema) {
        this.descripcionProblema = descripcionProblema;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }

    public void setRepuestosUtilizados(List<DetalleOrden> repuestosUtilizados) {
        this.repuestosUtilizados = repuestosUtilizados;
    }

    public void agregarRepuesto(DetalleOrden detalle) {
        this.repuestosUtilizados.add(detalle);
    }

    public double calcularCostoTotal() {
        double total = 0;
        for (DetalleOrden d : repuestosUtilizados) {
            total += d.getSubtotal();
        }
        this.costoTotal = total;
        return total;
    }

    @Override
    public String toString() {
        String mostrarOrden = (this.id != 0) ? "La orden es: " + this.id : "La orden no ha sido registrada.";
        return mostrarOrden + " | Estado: " + estado + " | Total: $" + costoTotal;
    }
}
