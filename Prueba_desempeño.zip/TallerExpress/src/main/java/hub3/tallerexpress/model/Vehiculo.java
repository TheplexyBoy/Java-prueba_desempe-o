/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class Vehiculo {

    private int id;
    private Cliente cliente; // relación con el cliente dueño
    private String placa;
    private String marca;
    private String modelo;
    private Integer anio;
    private LocalDateTime createdAt;

    public Vehiculo() {
    }

    public Vehiculo(int id, Cliente cliente, String placa, String marca, String modelo, Integer anio, LocalDateTime createdAt) {
        this.id = id;
        this.cliente = cliente;
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public String getPlaca() {
        return placa;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public Integer getAnio() {
        return anio;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        String mostrarVehiculo = (this.placa != null && !this.placa.trim().isEmpty()) ? this.placa : "Sin placa";
        return "Placa: " + mostrarVehiculo + " | Marca: " + marca + " " + modelo;
    }
}
