/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.model.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author coder
 */
public class VehiculoDAOImpl implements VehiculoDAO {

    @Override
    public void crear(Vehiculo vehiculo) throws PersistenciaException {
        String sql = "INSERT INTO vehiculos (cliente_id, placa, marca, modelo, anio) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, vehiculo.getCliente().getId());
            ps.setString(2, vehiculo.getPlaca());
            ps.setString(3, vehiculo.getMarca());
            ps.setString(4, vehiculo.getModelo());
            ps.setInt(5, vehiculo.getAnio());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al guardar el vehículo.", e);
        }
    }

    @Override
    public Vehiculo obtenerPorId(int id) throws PersistenciaException {
        String sql = "SELECT * FROM vehiculos WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerVehiculo(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al obtener el vehículo.", e);
        }
        return null;
    }

    @Override
    public List<Vehiculo> obtenerPorCliente(int clienteId) throws PersistenciaException {
        List<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM vehiculos WHERE cliente_id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clienteId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(extraerVehiculo(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los vehículos del cliente.", e);
        }
        return lista;
    }

    @Override
    public List<Vehiculo> obtenerTodos() throws PersistenciaException {
        List<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM vehiculos";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(extraerVehiculo(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los vehículos.", e);
        }
        return lista;
    }

    @Override
    public boolean existePlaca(String placa) throws PersistenciaException {
        String sql = "SELECT COUNT(*) FROM vehiculos WHERE placa = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, placa);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al validar la placa.", e);
        }
    }

    @Override
    public void actualizar(Vehiculo vehiculo) throws PersistenciaException {
        String sql = "UPDATE vehiculos SET placa=?, marca=?, modelo=?, anio=? WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, vehiculo.getPlaca());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el vehículo.", e);
        }
    }

    private Vehiculo extraerVehiculo(ResultSet rs) throws SQLException {
        Cliente c = new ClienteDAOImpl().obtenerPorId(rs.getInt("cliente_id"));

        return new Vehiculo(
                rs.getInt("id"),
                c,
                rs.getString("placa"),
                rs.getString("marca"),
                rs.getString("modelo"),
                rs.getInt("anio"),
                rs.getTimestamp("created_at").toLocalDateTime()
        );
    }
}