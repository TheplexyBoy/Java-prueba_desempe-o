/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.DetalleOrden;
import hub3.tallerexpress.model.Orden;
import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.model.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author coder
 */
public class OrdenDAOImpl implements OrdenDAO {

    @Override
    public void guardar(Orden orden) {
        String sqlOrden = "INSERT INTO ordenes_servicio (cliente_id, vehiculo_id, mecanico_responsable, fecha_ingreso, descripcion_problema, diagnostico, estado, costo_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO orden_repuestos (orden_id, repuesto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionDB.obtenerConexion()) {
            int ordenId;
            try (PreparedStatement stmt = con.prepareStatement(sqlOrden, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, orden.getVehiculo().getCliente().getId());
                stmt.setInt(2, orden.getVehiculo().getId());
                stmt.setString(3, orden.getMecanico());
                stmt.setTimestamp(4, Timestamp.valueOf(orden.getFechaIngreso()));
                stmt.setString(5, orden.getDescripcionProblema());
                stmt.setString(6, orden.getDiagnostico());
                stmt.setString(7, orden.getEstado());
                stmt.setDouble(8, orden.getCostoTotal());
                stmt.executeUpdate();

                try (ResultSet keys = stmt.getGeneratedKeys()) {
                    keys.next();
                    ordenId = keys.getInt(1);
                }
            }

            try (PreparedStatement stmtDetalle = con.prepareStatement(sqlDetalle)) {
                for (DetalleOrden d : orden.getRepuestosUtilizados()) {
                    stmtDetalle.setInt(1, ordenId);
                    stmtDetalle.setInt(2, d.getRepuesto().getId());
                    stmtDetalle.setInt(3, d.getCantidad());
                    stmtDetalle.setDouble(4, d.getPrecioUnitario());
                    stmtDetalle.addBatch();
                }
                stmtDetalle.executeBatch();
            }

            orden.setId(ordenId);
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al guardar la orden en la base de datos.", ex);
        }
    }

    @Override
    public Orden buscarPorId(int id) {
        String sql = "SELECT * FROM ordenes_servicio WHERE id = ?";
        Orden orden = null;

        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    orden = mapearOrden(rs);
                    orden.setRepuestosUtilizados(buscarDetalles(con, id));
                }
            }
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al buscar la orden por ID.", ex);
        }

        return orden;
    }

    @Override
    public List<Orden> listarTodos() {
        List<Orden> lista = new ArrayList<>();
        String sql = "SELECT * FROM ordenes_servicio";

        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement stmt = con.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Orden orden = mapearOrden(rs);
                orden.setRepuestosUtilizados(buscarDetalles(con, orden.getId()));
                lista.add(orden);
            }
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al listar las órdenes.", ex);
        }

        return lista;
    }

    private List<DetalleOrden> buscarDetalles(Connection con, int ordenId) throws SQLException {
        List<DetalleOrden> detalles = new ArrayList<>();
        String sql = "SELECT * FROM orden_repuestos WHERE orden_id = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, ordenId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Repuesto r = new Repuesto();
                    r.setId(rs.getInt("repuesto_id"));
                    detalles.add(new DetalleOrden(rs.getInt("id"), r, rs.getInt("cantidad"), rs.getDouble("precio_unitario")));
                }
            }
        }
        return detalles;
    }

    private Orden mapearOrden(ResultSet rs) throws SQLException {
        Orden orden = new Orden();

        orden.setId(rs.getInt("id"));
        orden.setMecanico(rs.getString("mecanico_responsable"));
        orden.setFechaIngreso(rs.getTimestamp("fecha_ingreso").toLocalDateTime());
        orden.setDescripcionProblema(rs.getString("descripcion_problema"));
        orden.setDiagnostico(rs.getString("diagnostico"));
        orden.setEstado(rs.getString("estado"));
        orden.setCostoTotal(rs.getDouble("costo_total"));

        Vehiculo v = new Vehiculo();
        v.setId(rs.getInt("vehiculo_id"));
        orden.setVehiculo(v);

        return orden;
    }

    @Override
    public void guardarTransaccional(Connection con, Orden orden) throws SQLException {
        String sqlOrden = "INSERT INTO ordenes_servicio (cliente_id, vehiculo_id, mecanico_responsable, fecha_ingreso, descripcion_problema, diagnostico, estado, costo_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO orden_repuestos (orden_id, repuesto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";

        int ordenId;
        try (PreparedStatement stmt = con.prepareStatement(sqlOrden, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, orden.getVehiculo().getCliente().getId());
            stmt.setInt(2, orden.getVehiculo().getId());
            stmt.setString(3, orden.getMecanico());
            stmt.setTimestamp(4, Timestamp.valueOf(orden.getFechaIngreso()));
            stmt.setString(5, orden.getDescripcionProblema());
            stmt.setString(6, orden.getDiagnostico());
            stmt.setString(7, orden.getEstado());
            stmt.setDouble(8, orden.getCostoTotal());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                keys.next();
                ordenId = keys.getInt(1);
            }
        }

        try (PreparedStatement stmtDetalle = con.prepareStatement(sqlDetalle)) {
            for (DetalleOrden d : orden.getRepuestosUtilizados()) {
                stmtDetalle.setInt(1, ordenId);
                stmtDetalle.setInt(2, d.getRepuesto().getId());
                stmtDetalle.setInt(3, d.getCantidad());
                stmtDetalle.setDouble(4, d.getPrecioUnitario());
                stmtDetalle.addBatch();
            }
            stmtDetalle.executeBatch();
        }

        orden.setId(ordenId);
    }

    @Override
    public void actualizar(Orden orden) {
        String sql = "UPDATE ordenes_servicio SET mecanico_responsable=?, descripcion_problema=?, diagnostico=?, estado=?, costo_total=? WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, orden.getMecanico());
            stmt.setString(2, orden.getDescripcionProblema());
            stmt.setString(3, orden.getDiagnostico());
            stmt.setString(4, orden.getEstado());
            stmt.setDouble(5, orden.getCostoTotal());
            stmt.setInt(6, orden.getId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al actualizar la orden.", ex);
        }
    }

    @Override
    public void eliminar(int id) {
        String sqlDetalle = "DELETE FROM orden_repuestos WHERE orden_id = ?";
        String sqlOrden = "DELETE FROM ordenes_servicio WHERE id = ?";

        try (Connection con = ConexionDB.obtenerConexion()) {
            try (PreparedStatement stmtDetalle = con.prepareStatement(sqlDetalle)) {
                stmtDetalle.setInt(1, id);
                stmtDetalle.executeUpdate();
            }
            try (PreparedStatement stmtOrden = con.prepareStatement(sqlOrden)) {
                stmtOrden.setInt(1, id);
                stmtOrden.executeUpdate();
            }
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al eliminar la orden.", ex);
        }
    }

    @Override
    public List<Orden> buscarPorVehiculo(int vehiculoId) {
        List<Orden> lista = new ArrayList<>();
        String sql = "SELECT * FROM ordenes_servicio WHERE vehiculo_id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, vehiculoId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Orden orden = mapearOrden(rs);
                    orden.setRepuestosUtilizados(buscarDetalles(con, orden.getId()));
                    lista.add(orden);
                }
            }
        } catch (SQLException ex) {
            throw new PersistenciaException("Error al buscar el historial del vehículo.", ex);
        }
        return lista;
    }

}
