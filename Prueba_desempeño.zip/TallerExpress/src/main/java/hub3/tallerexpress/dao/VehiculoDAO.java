/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Vehiculo;
import java.util.List;

/**
 *
 * @author coder
 */
public interface VehiculoDAO {

    void crear(Vehiculo vehiculo) throws PersistenciaException;

    Vehiculo obtenerPorId(int id) throws PersistenciaException;

    List<Vehiculo> obtenerPorCliente(int clienteId) throws PersistenciaException;

    List<Vehiculo> obtenerTodos() throws PersistenciaException;

    boolean existePlaca(String placa) throws PersistenciaException;

    void actualizar(Vehiculo vehiculo) throws PersistenciaException;
}