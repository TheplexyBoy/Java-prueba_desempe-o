/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.model.Orden;
import java.util.List;

/**
 *
 * @author coder
 */
public interface OrdenDAO {

    void guardar(Orden orden);

    Orden buscarPorId(int id);

    List<Orden> listarTodos();

    void actualizar(Orden orden);

    void eliminar(int id);
    
    void guardarTransaccional(java.sql.Connection con, Orden orden) throws java.sql.SQLException;

    List<Orden> buscarPorVehiculo(int vehiculoId);
}