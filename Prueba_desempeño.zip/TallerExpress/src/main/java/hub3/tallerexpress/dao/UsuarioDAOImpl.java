/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author coder
 */
public class UsuarioDAOImpl implements UsuarioDAO {

    @Override
    public void crear(Usuario usuario) throws PersistenciaException {
        String sql = "INSERT INTO usuarios (username, password, nombre_completo, role, estado) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getUsername());
            ps.setString(2, usuario.getPassword());
            ps.setString(3, usuario.getNombreCompleto());
            ps.setString(4, usuario.getRol());
            ps.setString(5, usuario.isActivo() ? "ACTIVO" : "INACTIVO");
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al guardar el usuario.", e);
        }
    }

    @Override
    public Usuario obtenerPorUsername(String username) throws PersistenciaException {
        String sql = "SELECT * FROM usuarios WHERE username = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerUsuario(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el usuario.", e);
        }
        return null;
    }

    @Override
    public Usuario obtenerPorId(int id) throws PersistenciaException {
        String sql = "SELECT * FROM usuarios WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerUsuario(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al obtener el usuario.", e);
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerTodos() throws PersistenciaException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(extraerUsuario(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los usuarios.", e);
        }
        return lista;
    }

    @Override
    public boolean existeUsername(String username) throws PersistenciaException {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE username = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al validar el username.", e);
        }
    }

    @Override
    public void actualizar(Usuario usuario) throws PersistenciaException {
        String sql = "UPDATE usuarios SET nombre_completo=?, role=? WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombreCompleto());
            ps.setString(2, usuario.getRol());
            ps.setInt(3, usuario.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el usuario.", e);
        }
    }

    @Override
    public void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException {
        String sql = "UPDATE usuarios SET estado = ? WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado ? "ACTIVO" : "INACTIVO");
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al cambiar el estado del usuario.", e);
        }
    }

    private Usuario extraerUsuario(ResultSet rs) throws SQLException {
        return new Usuario(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("password"),
                rs.getString("nombre_completo"),
                rs.getString("role"),
                "ACTIVO".equals(rs.getString("estado")),
                rs.getTimestamp("created_at").toLocalDateTime()
        );
    }
}
