/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Repuesto;
import java.util.List;

/**
 *
 * @author coder
 */
public interface RepuestoDAO {

    void crear(Repuesto repuesto) throws PersistenciaException;

    Repuesto obtenerPorId(int id) throws PersistenciaException;

    Repuesto obtenerPorCodigo(String codigoReferencia) throws PersistenciaException;

    List<Repuesto> obtenerTodos() throws PersistenciaException;

    List<Repuesto> filtrar(String categoria, String proveedor) throws PersistenciaException;

    boolean existeCodigo(String codigoReferencia) throws PersistenciaException;

    void actualizar(Repuesto repuesto) throws PersistenciaException;

    void actualizarStock(int id, int nuevoStockDisponible) throws PersistenciaException;

    void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException;

    void descontarStock(java.sql.Connection con, int repuestoId, int cantidad) throws java.sql.SQLException, hub3.tallerexpress.exception.ValidacionException;
}
