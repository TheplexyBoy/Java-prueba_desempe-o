/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Repuesto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author coder
 */
public class RepuestoDAOImpl implements RepuestoDAO {

    @Override
    public void crear(Repuesto repuesto) throws PersistenciaException {
        String sql = "INSERT INTO repuestos (codigo_referencia, nombre, categoria, proveedor, stock_total, stock_disponible, precio_unitario, is_activo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, repuesto.getCodigoReferencia());
            ps.setString(2, repuesto.getNombre());
            ps.setString(3, repuesto.getCategoria());
            ps.setString(4, repuesto.getProveedor());
            ps.setInt(5, repuesto.getStockTotal());
            ps.setInt(6, repuesto.getStockDisponible());
            ps.setDouble(7, repuesto.getPrecioUnitario());
            ps.setBoolean(8, repuesto.isIsActivo());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al guardar el repuesto.", e);
        }
    }

    @Override
    public Repuesto obtenerPorId(int id) throws PersistenciaException {
        String sql = "SELECT * FROM repuestos WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerRepuesto(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al obtener el repuesto.", e);
        }
        return null;
    }

    @Override
    public Repuesto obtenerPorCodigo(String codigoReferencia) throws PersistenciaException {
        String sql = "SELECT * FROM repuestos WHERE codigo_referencia = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigoReferencia);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerRepuesto(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el repuesto por código.", e);
        }
        return null;
    }

    @Override
    public List<Repuesto> obtenerTodos() throws PersistenciaException {
        List<Repuesto> lista = new ArrayList<>();
        String sql = "SELECT * FROM repuestos";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(extraerRepuesto(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los repuestos.", e);
        }
        return lista;
    }

    @Override
    public List<Repuesto> filtrar(String categoria, String proveedor) throws PersistenciaException {
        List<Repuesto> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM repuestos WHERE 1=1");
        if (categoria != null && !categoria.isBlank()) {
            sql.append(" AND categoria = ?");
        }
        if (proveedor != null && !proveedor.isBlank()) {
            sql.append(" AND proveedor = ?");
        }

        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            if (categoria != null && !categoria.isBlank()) {
                ps.setString(i++, categoria);
            }
            if (proveedor != null && !proveedor.isBlank()) {
                ps.setString(i++, proveedor);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(extraerRepuesto(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al filtrar los repuestos.", e);
        }
        return lista;
    }

    @Override
    public boolean existeCodigo(String codigoReferencia) throws PersistenciaException {
        String sql = "SELECT COUNT(*) FROM repuestos WHERE codigo_referencia = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigoReferencia);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al validar el código de referencia.", e);
        }
    }

    @Override
    public void actualizar(Repuesto repuesto) throws PersistenciaException {
        String sql = "UPDATE repuestos SET nombre=?, categoria=?, proveedor=?, stock_total=?, stock_disponible=?, precio_unitario=? WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, repuesto.getNombre());
            ps.setString(2, repuesto.getCategoria());
            ps.setString(3, repuesto.getProveedor());
            ps.setInt(4, repuesto.getStockTotal());
            ps.setInt(5, repuesto.getStockDisponible());
            ps.setDouble(6, repuesto.getPrecioUnitario());
            ps.setInt(7, repuesto.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el repuesto.", e);
        }
    }

    @Override
    public void actualizarStock(int id, int nuevoStockDisponible) throws PersistenciaException {
        String sql = "UPDATE repuestos SET stock_disponible = ? WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, nuevoStockDisponible);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el stock del repuesto.", e);
        }
    }

    @Override
    public void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException {
        String sql = "UPDATE repuestos SET is_activo = ? WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, nuevoEstado);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al cambiar el estado del repuesto.", e);
        }
    }
    
        @Override
    public void descontarStock(Connection con, int repuestoId, int cantidad) throws SQLException {
        String sqlLeer = "SELECT stock_disponible FROM repuestos WHERE id = ? FOR UPDATE";
        int stockActual;
        try (PreparedStatement ps = con.prepareStatement(sqlLeer)) {
            ps.setInt(1, repuestoId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new hub3.tallerexpress.exception.ValidacionException("El repuesto no existe.");
                }
                stockActual = rs.getInt("stock_disponible");
            }
        }
        if (cantidad > stockActual) {
            throw new hub3.tallerexpress.exception.ValidacionException("Stock insuficiente para el repuesto id=" + repuestoId);
        }
        String sqlUpdate = "UPDATE repuestos SET stock_disponible = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sqlUpdate)) {
            ps.setInt(1, stockActual - cantidad);
            ps.setInt(2, repuestoId);
            ps.executeUpdate();
        }
    }

    private Repuesto extraerRepuesto(ResultSet rs) throws SQLException {
        return new Repuesto(
                rs.getInt("id"),
                rs.getString("codigo_referencia"),
                rs.getString("nombre"),
                rs.getString("categoria"),
                rs.getString("proveedor"),
                rs.getInt("stock_total"),
                rs.getInt("stock_disponible"),
                rs.getDouble("precio_unitario"),
                rs.getBoolean("is_activo"),
                rs.getTimestamp("created_at").toLocalDateTime()
        );
    }
}
