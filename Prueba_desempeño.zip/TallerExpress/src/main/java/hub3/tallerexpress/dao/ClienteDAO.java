/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Cliente;
import java.util.List;

/**
 *
 * @author coder
 */
public interface ClienteDAO {

    // Volvemos al void que conoces
    void crear(Cliente cliente) throws PersistenciaException;

    Cliente obtenerPorId(int id) throws PersistenciaException;

    List<Cliente> obtenerTodos() throws PersistenciaException;

    void actualizar(Cliente cliente) throws PersistenciaException;

    void eliminarFisico(int id) throws PersistenciaException;

    void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException;
}
