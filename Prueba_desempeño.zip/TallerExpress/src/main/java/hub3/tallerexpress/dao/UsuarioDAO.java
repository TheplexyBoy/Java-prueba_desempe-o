/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.dao;

import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Usuario;
import java.util.List;

/**
 *
 * @author coder
 */
public interface UsuarioDAO {

    void crear(Usuario usuario) throws PersistenciaException;

    Usuario obtenerPorUsername(String username) throws PersistenciaException;

    Usuario obtenerPorId(int id) throws PersistenciaException;

    List<Usuario> obtenerTodos() throws PersistenciaException;

    boolean existeUsername(String username) throws PersistenciaException;

    void actualizar(Usuario usuario) throws PersistenciaException;

    void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException;
}