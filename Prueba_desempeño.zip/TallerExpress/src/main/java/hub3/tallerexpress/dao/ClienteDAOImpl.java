package hub3.tallerexpress.dao;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.model.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAOImpl implements ClienteDAO {

    @Override
    public void crear(Cliente cliente) throws PersistenciaException {
        String sql = "INSERT INTO clientes (nombre, documento, telefono, email, direccion, activo) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getDocumento());
            ps.setString(3, cliente.getTelefono());
            ps.setString(4, cliente.getEmail());
            ps.setString(5, cliente.getDireccion());
            ps.setBoolean(6, cliente.isActivo());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al guardar el cliente.", e);
        }
    }

    @Override
    public Cliente obtenerPorId(int id) throws PersistenciaException {
        String sql = "SELECT * FROM clientes WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extraerCliente(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al obtener el cliente por ID.", e);
        }
        return null;
    }

    @Override
    public List<Cliente> obtenerTodos() throws PersistenciaException {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(extraerCliente(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los clientes.", e);
        }
        return lista;
    }

    @Override
    public void actualizar(Cliente cliente) throws PersistenciaException {
        String sql = "UPDATE clientes SET nombre=?, documento=?, telefono=?, email=?, direccion=?, activo=? WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getDocumento());
            ps.setString(3, cliente.getTelefono());
            ps.setString(4, cliente.getEmail());
            ps.setString(5, cliente.getDireccion());
            ps.setBoolean(6, cliente.isActivo());
            ps.setInt(7, cliente.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el cliente.", e);
        }
    }

    @Override
    public void cambiarEstado(int id, boolean nuevoEstado) throws PersistenciaException {
        String sql = "UPDATE clientes SET activo = ? WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, nuevoEstado);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al cambiar el estado del cliente.", e);
        }
    }

    private Cliente extraerCliente(ResultSet rs) throws SQLException {
        return new Cliente(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("documento"),
                rs.getString("telefono"),
                rs.getString("email"),
                rs.getString("direccion"),
                rs.getBoolean("activo"),
                rs.getTimestamp("created_at").toLocalDateTime()
        );
    }

    @Override
    public void eliminarFisico(int id) throws PersistenciaException {
        String sql = "DELETE FROM clientes WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenciaException("Error al eliminar físicamente el cliente.", e);
        }
    }
}
