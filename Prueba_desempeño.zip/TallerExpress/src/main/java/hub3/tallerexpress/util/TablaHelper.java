/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.util;

import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.model.Orden;
import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.model.Vehiculo;
import java.util.List;

/**
 *
 * @author coder
 */
public class TablaHelper {

    public static String tablaRepuestos(List<Repuesto> repuestos) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-20s %-12s %8s %8s %10s %-10s%n",
                "CODIGO", "NOMBRE", "CATEGORIA", "STOCK_T", "STOCK_D", "PRECIO", "ESTADO"));
        for (Repuesto r : repuestos) {
            String estado = r.isIsActivo() ? "[ACTIVO]" : "[INACTIVO]";
            sb.append(String.format("%-10s %-20s %-12s %8d %8d %10.2f %-10s%n",
                    r.getCodigoReferencia(), r.getNombre(), r.getCategoria(),
                    r.getStockTotal(), r.getStockDisponible(), r.getPrecioUnitario(), estado));
        }
        return sb.toString();
    }

    public static String tablaClientes(List<Cliente> clientes) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-20s %-15s %-15s %-10s%n",
                "ID", "NOMBRE", "DOCUMENTO", "TELEFONO", "ESTADO"));
        for (Cliente c : clientes) {
            String estado = c.isActivo() ? "[ACTIVO]" : "[INACTIVO]";
            sb.append(String.format("%-5d %-20s %-15s %-15s %-10s%n",
                    c.getId(), c.getNombre(), c.getDocumento(), c.getTelefono(), estado));
        }
        return sb.toString();
    }

    public static String tablaVehiculos(List<Vehiculo> vehiculos) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-10s %-12s %-12s %-6s %-20s%n",
                "ID", "PLACA", "MARCA", "MODELO", "ANIO", "CLIENTE"));
        for (Vehiculo v : vehiculos) {
            String cliente = (v.getCliente() != null) ? v.getCliente().getNombre() : "N/D";
            sb.append(String.format("%-5d %-10s %-12s %-12s %-6d %-20s%n",
                    v.getId(), v.getPlaca(), v.getMarca(), v.getModelo(), v.getAnio(), cliente));
        }
        return sb.toString();
    }

    public static String tablaUsuarios(List<Usuario> usuarios) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-15s %-20s %-14s %-10s%n",
                "ID", "USERNAME", "NOMBRE", "ROL", "ESTADO"));
        for (Usuario u : usuarios) {
            String estado = u.isActivo() ? "[ACTIVO]" : "[INACTIVO]";
            sb.append(String.format("%-5d %-15s %-20s %-14s %-10s%n",
                    u.getId(), u.getUsername(), u.getNombreCompleto(), u.getRol(), estado));
        }
        return sb.toString();
    }

    public static String tablaOrdenes(List<Orden> ordenes) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-10s %-18s %-15s %10s%n",
                "ID", "VEHICULO", "MECANICO", "ESTADO", "TOTAL"));
        for (Orden o : ordenes) {
            String placa = (o.getVehiculo() != null) ? o.getVehiculo().getPlaca() : "N/D";
            sb.append(String.format("%-5d %-10s %-18s %-15s %10.2f%n",
                    o.getId(), placa, o.getMecanico(), o.getEstado(), o.getCostoTotal()));
        }
        return sb.toString();
    }
}