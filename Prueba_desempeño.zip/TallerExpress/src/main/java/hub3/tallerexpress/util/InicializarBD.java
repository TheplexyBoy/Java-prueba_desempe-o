/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.util;

import hub3.tallerexpress.config.ConexionDB;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author coder
 */
public class InicializarBD {
    public static void main(String[] args) {
        try {
            String sql = Files.readString(Paths.get("tablas.sql"));

            try (Connection con = ConexionDB.obtenerConexion()) {

                try (Statement stmt = con.createStatement()) {
                    for (String comando : sql.split(";")) {
                        if (!comando.isBlank()) {
                            stmt.execute(comando);
                        }
                    }
                    System.out.println("¡Tablas creadas con éxito!");
                }

                String sqlInsert = "INSERT INTO usuarios (username, password, nombre_completo, role, estado) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement ps = con.prepareStatement(sqlInsert)) {
                    ps.setString(1, "admin");
                    ps.setString(2, "admin123");
                    ps.setString(3, "Administrador General");
                    ps.setString(4, "ADMIN");
                    ps.setString(5, "ACTIVO");
                    ps.executeUpdate();
                    System.out.println("¡Usuario admin creado con éxito! (admin / admin123)");
                }

            }
        } catch (IOException e) {
            System.out.println("No encontré el archivo tablas.sql. Revisa la ruta.");
        } catch (Exception e) {
            System.out.println("Error inicializando la base de datos: " + e.getMessage());
        }
    }
}