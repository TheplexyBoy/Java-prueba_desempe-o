/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.util;

/**
 *
 * @author coder
 */
public class LogHttp {
    public static void log(String metodo, String endpoint, String detalle) {
        System.out.println("[" + metodo + "] " + endpoint + " -> " + detalle);
    }
}