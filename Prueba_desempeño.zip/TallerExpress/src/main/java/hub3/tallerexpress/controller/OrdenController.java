/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.controller;

import hub3.tallerexpress.model.Orden;
import hub3.tallerexpress.service.OrdenService;
import java.util.List;

/**
 *
 * @author coder
 */
public class OrdenController {

    private final OrdenService ordenService;

    public OrdenController() {
        this.ordenService = new OrdenService();
    }

    public void registrar(Orden orden) {
        ordenService.registrarOrden(orden);
    }

    public List<Orden> listarTodas() {
        return ordenService.listarTodas();
    }

    public Orden buscarPorId(int id) {
        return ordenService.buscarPorId(id);
    }

    public void actualizarEstado(int ordenId, String nuevoEstado) {
        ordenService.actualizarEstado(ordenId, nuevoEstado);
    }

    public java.util.List<Orden> listarPorVehiculo(int vehiculoId) {
        return ordenService.listarPorVehiculo(vehiculoId);
    }
}
