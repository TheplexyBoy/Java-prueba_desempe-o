/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.controller;

import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.service.UsuarioService;
import java.util.List;

/**
 *
 * @author coder
 */
public class UsuarioController {

    private final UsuarioService usuarioService;
    private Usuario usuarioEnSesion;

    public UsuarioController() {
        this.usuarioService = new UsuarioService();
    }

    public void registrar(Usuario usuario) {
        usuarioService.registrarUsuario(usuario);
    }

    public Usuario login(String username, String password) {
        this.usuarioEnSesion = usuarioService.login(username, password);
        return usuarioEnSesion;
    }

    public Usuario getUsuarioEnSesion() {
        return usuarioEnSesion;
    }

    public boolean esAdmin() {
        return usuarioEnSesion != null && "ADMIN".equals(usuarioEnSesion.getRol());
    }

    public List<Usuario> listar() {
        return usuarioService.listarUsuarios();
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        usuarioService.cambiarEstado(id, nuevoEstado);
    }

    public Usuario buscarPorId(int id) {
        return usuarioService.buscarPorId(id);
    }

    public void actualizar(Usuario usuario) {
        usuarioService.actualizar(usuario);
    }
}
