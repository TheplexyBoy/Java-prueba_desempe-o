/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.controller;

import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.service.RepuestoService;
import java.util.List;

/**
 *
 * @author coder
 */
public class RepuestoController {

    private final RepuestoService repuestoService;

    public RepuestoController() {
        this.repuestoService = new RepuestoService();
    }

    public void registrar(Repuesto repuesto) {
        repuestoService.registrarRepuesto(repuesto);
    }

    public List<Repuesto> listarTodos() {
        return repuestoService.listarTodos();
    }

    public List<Repuesto> filtrar(String categoria, String proveedor) {
        return repuestoService.filtrar(categoria, proveedor);
    }

    public void actualizar(Repuesto repuesto) {
        repuestoService.actualizarRepuesto(repuesto);
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        repuestoService.cambiarEstado(id, nuevoEstado);
    }

    public Repuesto buscarPorId(int id) {
        return repuestoService.buscarPorId(id);
    }

    public Repuesto buscarPorCodigo(String codigo) {
        return repuestoService.buscarPorCodigo(codigo);
    }
}
