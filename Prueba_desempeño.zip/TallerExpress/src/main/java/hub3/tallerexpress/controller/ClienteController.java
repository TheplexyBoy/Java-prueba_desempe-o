/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.controller;

import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.service.ClienteService;
import java.util.List;

/**
 *
 * @author coder
 */
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController() {
        this.clienteService = new ClienteService();
    }

    public void registrar(Cliente cliente) {
        clienteService.registrarCliente(cliente);
    }

    public List<Cliente> listar() {
        return clienteService.listarClientes();
    }

    public Cliente buscarPorId(int id) {
        return clienteService.buscarPorId(id);
    }

    public void actualizar(Cliente cliente) {
        clienteService.actualizarCliente(cliente);
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        clienteService.cambiarEstado(id, nuevoEstado);
    }
}
