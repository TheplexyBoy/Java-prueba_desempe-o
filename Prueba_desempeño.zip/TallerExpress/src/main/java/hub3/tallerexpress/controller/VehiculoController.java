/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.controller;

import hub3.tallerexpress.model.Vehiculo;
import hub3.tallerexpress.service.VehiculoService;
import java.util.List;

/**
 *
 * @author coder
 */
public class VehiculoController {

    private final VehiculoService vehiculoService;

    public VehiculoController() {
        this.vehiculoService = new VehiculoService();
    }

    public void registrar(Vehiculo vehiculo) {
        vehiculoService.registrarVehiculo(vehiculo);
    }

    public List<Vehiculo> listarPorCliente(int clienteId) {
        return vehiculoService.listarPorCliente(clienteId);
    }

    public List<Vehiculo> listarTodos() {
        return vehiculoService.listarTodos();
    }

    public void actualizar(Vehiculo vehiculo) {
        vehiculoService.actualizarVehiculo(vehiculo);
    }

    public Vehiculo buscarPorId(int id) {
        return vehiculoService.buscarPorId(id);
    }
}
