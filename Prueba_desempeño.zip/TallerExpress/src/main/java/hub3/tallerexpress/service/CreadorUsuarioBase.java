/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.dao.UsuarioDAO;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.util.LogHttp;

/**
 *
 * @author coder
 */
public class CreadorUsuarioBase implements CreadorUsuario {

    private final UsuarioDAO usuarioDAO;

    public CreadorUsuarioBase(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    @Override
    public void crear(Usuario usuario) {
        if (usuario.getUsername() == null || usuario.getUsername().isBlank()) {
            throw new ValidacionException("El username es obligatorio.");
        }
        if (usuarioDAO.existeUsername(usuario.getUsername())) {
            throw new ValidacionException("Ya existe un usuario con ese username.");
        }
        usuarioDAO.crear(usuario);
        LogHttp.log("POST", "/usuarios", "Usuario creado: " + usuario.getUsername());
    }
}