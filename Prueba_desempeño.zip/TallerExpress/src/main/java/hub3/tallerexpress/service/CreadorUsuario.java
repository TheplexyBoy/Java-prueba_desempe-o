/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.model.Usuario;

/**
 *
 * @author coder
 */
public interface CreadorUsuario {
    void crear(Usuario usuario);
}
