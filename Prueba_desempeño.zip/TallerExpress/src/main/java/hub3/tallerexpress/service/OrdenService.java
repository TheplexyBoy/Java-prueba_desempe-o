/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.dao.OrdenDAO;
import hub3.tallerexpress.dao.OrdenDAOImpl;
import hub3.tallerexpress.dao.RepuestoDAO;
import hub3.tallerexpress.dao.RepuestoDAOImpl;
import hub3.tallerexpress.exception.PersistenciaException;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.DetalleOrden;
import hub3.tallerexpress.model.Orden;
import hub3.tallerexpress.util.LogHttp;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author coder
 */
public class OrdenService {

    private final OrdenDAO ordenDAO;
    private final RepuestoDAO repuestoDAO;

    public OrdenService() {
        this.ordenDAO = new OrdenDAOImpl();
        this.repuestoDAO = new RepuestoDAOImpl();
    }

    public List<Orden> listarPorVehiculo(int vehiculoId) {
        LogHttp.log("GET", "/vehiculos/" + vehiculoId + "/ordenes", "Historial de servicios");
        return ordenDAO.buscarPorVehiculo(vehiculoId);
    }

    // Registro de Orden -> setAutoCommit(false) -> insertar orden -> actualizar inventario -> commit()/rollback()
    public void registrarOrden(Orden orden) {
        if (orden.getVehiculo() == null) {
            throw new ValidacionException("La orden debe tener un vehículo asociado.");
        }
        if (orden.getMecanico() == null || orden.getMecanico().isBlank()) {
            throw new ValidacionException("Debe indicar el mecánico responsable.");
        }
        orden.setFechaIngreso(LocalDateTime.now());
        orden.calcularCostoTotal();

        try (Connection con = ConexionDB.obtenerConexion()) {
            con.setAutoCommit(false);
            try {
                ordenDAO.guardarTransaccional(con, orden);

                for (DetalleOrden detalle : orden.getRepuestosUtilizados()) {
                    repuestoDAO.descontarStock(con, detalle.getRepuesto().getId(), detalle.getCantidad());
                }

                con.commit();
                LogHttp.log("POST", "/ordenes", "Orden registrada #" + orden.getId());
            } catch (SQLException | ValidacionException e) {
                con.rollback();
                throw new PersistenciaException("No se pudo registrar la orden, se revirtieron los cambios.", e);
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error de conexión al registrar la orden.", e);
        }
    }

    public java.util.List<Orden> listarTodas() {
        LogHttp.log("GET", "/ordenes", "Listando órdenes");
        return ordenDAO.listarTodos();
    }

    public Orden buscarPorId(int id) {
        LogHttp.log("GET", "/ordenes/" + id, "Buscando orden");
        return ordenDAO.buscarPorId(id);
    }

    // Permite actualizar el estado de la orden (RECIBIDA, EN_DIAGNOSTICO, etc.)
    public void actualizarEstado(int ordenId, String nuevoEstado) {
        Orden orden = ordenDAO.buscarPorId(ordenId);
        if (orden == null) {
            throw new ValidacionException("La orden no existe.");
        }
        orden.setEstado(nuevoEstado);
        ordenDAO.actualizar(orden);
        LogHttp.log("PATCH", "/ordenes/" + ordenId, "Estado cambiado a " + nuevoEstado);
    }
}
