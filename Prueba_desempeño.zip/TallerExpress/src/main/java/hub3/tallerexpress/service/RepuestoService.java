/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.dao.RepuestoDAO;
import hub3.tallerexpress.dao.RepuestoDAOImpl;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Repuesto;
import hub3.tallerexpress.util.LogHttp;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author coder
 */
public class RepuestoService {

    private final RepuestoDAO repuestoDAO;

    public RepuestoService() {
        this.repuestoDAO = new RepuestoDAOImpl();
    }

    public void registrarRepuesto(Repuesto repuesto) {
        if (repuesto.getCodigoReferencia() == null || repuesto.getCodigoReferencia().isBlank()) {
            throw new ValidacionException("El código de referencia es obligatorio.");
        }
        if (repuestoDAO.existeCodigo(repuesto.getCodigoReferencia())) {
            throw new ValidacionException("Ya existe un repuesto con ese código de referencia.");
        }
        if (repuesto.getStockDisponible() < 0 || repuesto.getStockTotal() < 0) {
            throw new ValidacionException("El stock no puede ser negativo.");
        }
        repuesto.setIsActivo(true);
        repuesto.setCreatedAt(LocalDateTime.now());
        repuestoDAO.crear(repuesto);
        LogHttp.log("POST", "/repuestos", "Repuesto creado: " + repuesto.getCodigoReferencia());
    }

    public List<Repuesto> listarTodos() {
        LogHttp.log("GET", "/repuestos", "Listando repuestos");
        return repuestoDAO.obtenerTodos();
    }

    public List<Repuesto> filtrar(String categoria, String proveedor) {
        LogHttp.log("GET", "/repuestos", "Filtrando por categoria/proveedor");
        return repuestoDAO.filtrar(categoria, proveedor);
    }

    public void actualizarRepuesto(Repuesto repuesto) {
        if (repuesto.getStockDisponible() < 0) {
            throw new ValidacionException("El stock disponible no puede ser negativo.");
        }
        repuestoDAO.actualizar(repuesto);
        LogHttp.log("PATCH", "/repuestos/" + repuesto.getId(), "Repuesto actualizado");
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        repuestoDAO.cambiarEstado(id, nuevoEstado);
        LogHttp.log("PATCH", "/repuestos/" + id, "Estado cambiado a " + (nuevoEstado ? "ACTIVO" : "INACTIVO"));
    }
    
        public Repuesto buscarPorId(int id) {
        return repuestoDAO.obtenerPorId(id);
    }

    public Repuesto buscarPorCodigo(String codigo) {
        return repuestoDAO.obtenerPorCodigo(codigo);
    }

    public void descontarStock(int repuestoId, int cantidad) {
        Repuesto r = repuestoDAO.obtenerPorId(repuestoId);
        if (r == null) {
            throw new ValidacionException("El repuesto no existe.");
        }
        if (cantidad > r.getStockDisponible()) {
            throw new ValidacionException("Stock insuficiente para el repuesto " + r.getCodigoReferencia());
        }
        repuestoDAO.actualizarStock(repuestoId, r.getStockDisponible() - cantidad);
        LogHttp.log("PATCH", "/repuestos/" + repuestoId, "Stock actualizado");
    }
}