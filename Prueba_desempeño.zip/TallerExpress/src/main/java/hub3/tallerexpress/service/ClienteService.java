/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.dao.ClienteDAO;
import hub3.tallerexpress.dao.ClienteDAOImpl;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Cliente;
import hub3.tallerexpress.util.LogHttp;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author coder
 */
public class ClienteService {

    private final ClienteDAO clienteDAO;

    public ClienteService() {
        this.clienteDAO = new ClienteDAOImpl();
    }

    public void registrarCliente(Cliente cliente) {
        if (cliente.getNombre() == null || cliente.getNombre().isBlank()) {
            throw new ValidacionException("El nombre del cliente es obligatorio.");
        }
        if (cliente.getDocumento() == null || cliente.getDocumento().isBlank()) {
            throw new ValidacionException("El documento del cliente es obligatorio.");
        }
        cliente.setActivo(true);
        cliente.setCreatedAt(LocalDateTime.now());
        clienteDAO.crear(cliente);
        LogHttp.log("POST", "/clientes", "Cliente creado: " + cliente.getDocumento());
    }

    public List<Cliente> listarClientes() {
        LogHttp.log("GET", "/clientes", "Listando clientes");
        return clienteDAO.obtenerTodos();
    }

    public Cliente buscarPorId(int id) {
        LogHttp.log("GET", "/clientes/" + id, "Buscando cliente");
        return clienteDAO.obtenerPorId(id);
    }

    public void actualizarCliente(Cliente cliente) {
        if (cliente.getNombre() == null || cliente.getNombre().isBlank()) {
            throw new ValidacionException("El nombre del cliente es obligatorio.");
        }
        clienteDAO.actualizar(cliente);
        LogHttp.log("PATCH", "/clientes/" + cliente.getId(), "Cliente actualizado");
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        clienteDAO.cambiarEstado(id, nuevoEstado);
        LogHttp.log("PATCH", "/clientes/" + id, "Estado cambiado a " + (nuevoEstado ? "ACTIVO" : "INACTIVO"));
    }

    public boolean esClienteActivoValido(int clienteId) {
        Cliente c = clienteDAO.obtenerPorId(clienteId);
        return c != null && c.isActivo();
    }
}
