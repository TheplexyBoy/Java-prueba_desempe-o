/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.dao.UsuarioDAO;
import hub3.tallerexpress.dao.UsuarioDAOImpl;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.util.LogHttp;
import java.util.List;

/**
 *
 * @author coder
 */
public class UsuarioService {

    private final UsuarioDAO usuarioDAO;
    private final CreadorUsuario creador;

    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAOImpl();
        // aquí se arma el "regalo envuelto": la base + el decorador encima
        this.creador = new CreadorUsuarioConValoresPorDefecto(new CreadorUsuarioBase(usuarioDAO));
    }

    public Usuario buscarPorId(int id) {
        return usuarioDAO.obtenerPorId(id);
    }

    public void registrarUsuario(Usuario usuario) {
        creador.crear(usuario);
    }

    public Usuario login(String username, String password) {
        Usuario u = usuarioDAO.obtenerPorUsername(username);
        if (u == null || !u.getPassword().equals(password)) {
            throw new ValidacionException("Usuario o contraseña incorrectos.");
        }
        if (!u.isActivo()) {
            throw new ValidacionException("El usuario está inactivo.");
        }
        LogHttp.log("POST", "/login", "Login exitoso: " + username);
        return u;
    }

    public List<Usuario> listarUsuarios() {
        LogHttp.log("GET", "/usuarios", "Listando usuarios");
        return usuarioDAO.obtenerTodos();
    }

    public void cambiarEstado(int id, boolean nuevoEstado) {
        usuarioDAO.cambiarEstado(id, nuevoEstado);
        LogHttp.log("PATCH", "/usuarios/" + id, "Estado cambiado a " + (nuevoEstado ? "ACTIVO" : "INACTIVO"));
    }

    public void actualizar(Usuario usuario) {
        usuarioDAO.actualizar(usuario);
    }
}
