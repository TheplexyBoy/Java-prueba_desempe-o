/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.model.Usuario;
import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class CreadorUsuarioConValoresPorDefecto implements CreadorUsuario {

    private final CreadorUsuario creadorOriginal;

    public CreadorUsuarioConValoresPorDefecto(CreadorUsuario creadorOriginal) {
        this.creadorOriginal = creadorOriginal;
    }

    @Override
    public void crear(Usuario usuario) {
        if (usuario.getRol() == null || usuario.getRol().isBlank()) {
            usuario.setRol("RECEPCIONISTA");
        }
        usuario.setActivo(true);
        usuario.setCreatedAt(LocalDateTime.now());

        creadorOriginal.crear(usuario); // aquí llama a la caja original, sin tocarla
    }
}