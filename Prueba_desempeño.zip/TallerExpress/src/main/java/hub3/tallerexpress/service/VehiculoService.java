/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.tallerexpress.service;

import hub3.tallerexpress.dao.VehiculoDAO;
import hub3.tallerexpress.dao.VehiculoDAOImpl;
import hub3.tallerexpress.exception.ValidacionException;
import hub3.tallerexpress.model.Vehiculo;
import hub3.tallerexpress.util.LogHttp;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author coder
 */
public class VehiculoService {

    private final VehiculoDAO vehiculoDAO;
    private final ClienteService clienteService;

    public VehiculoService() {
        this.vehiculoDAO = new VehiculoDAOImpl();
        this.clienteService = new ClienteService();
    }
    
    public Vehiculo buscarPorId(int id) {
        return vehiculoDAO.obtenerPorId(id);
    }

    public void registrarVehiculo(Vehiculo vehiculo) {
        if (vehiculo.getPlaca() == null || vehiculo.getPlaca().isBlank()) {
            throw new ValidacionException("La placa es obligatoria.");
        }
        if (vehiculo.getCliente() == null) {
            throw new ValidacionException("El vehículo debe tener un cliente asociado.");
        }
        if (!clienteService.esClienteActivoValido(vehiculo.getCliente().getId())) {
            throw new ValidacionException("El cliente no existe o está inactivo.");
        }
        if (vehiculoDAO.existePlaca(vehiculo.getPlaca())) {
            throw new ValidacionException("Ya existe un vehículo registrado con esa placa.");
        }
        vehiculo.setCreatedAt(LocalDateTime.now());
        vehiculoDAO.crear(vehiculo);
        LogHttp.log("POST", "/vehiculos", "Vehículo creado: " + vehiculo.getPlaca());
    }

    public List<Vehiculo> listarPorCliente(int clienteId) {
        LogHttp.log("GET", "/clientes/" + clienteId + "/vehiculos", "Listando vehículos del cliente");
        return vehiculoDAO.obtenerPorCliente(clienteId);
    }

    public List<Vehiculo> listarTodos() {
        LogHttp.log("GET", "/vehiculos", "Listando vehículos");
        return vehiculoDAO.obtenerTodos();
    }

    public void actualizarVehiculo(Vehiculo vehiculo) {
        vehiculoDAO.actualizar(vehiculo);
        LogHttp.log("PATCH", "/vehiculos/" + vehiculo.getId(), "Vehículo actualizado");
    }
}
