package hub3.tallerexpress.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    
    private static final String URL = "jdbc:h2:./tallerexpress_db";
    
    private static final String USER = "sa"; 
    
    private static final String PASSWORD = ""; 

    public static Connection obtenerConexion() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error fatal al conectar con H2: " + e.getMessage());
            return null;
        }
    }
}