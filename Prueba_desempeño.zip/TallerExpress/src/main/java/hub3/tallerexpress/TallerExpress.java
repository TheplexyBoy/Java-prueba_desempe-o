/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hub3.tallerexpress;

import hub3.tallerexpress.config.ConexionDB;
import hub3.tallerexpress.controller.UsuarioController;
import hub3.tallerexpress.model.Usuario;
import hub3.tallerexpress.presentation.LoginView;
import hub3.tallerexpress.presentation.MenuPrincipalView;
import java.sql.Connection;

/**
 *
 * @author coder
 */
public class TallerExpress {

    public static void main(String[] args) {
        UsuarioController usuarioController = new UsuarioController();

        Usuario usuario = new LoginView(usuarioController).mostrar();

        if (usuario != null) {
            new MenuPrincipalView(usuarioController).mostrar();
        }

        System.out.println("Programa finalizado.");
    }
}