-- =========================================================
-- TallerExpress - Esquema de base de datos (H2)
-- =========================================================
-- Diseñado para ejecutarse tal cual en H2. Es compatible en su
-- mayoría con MySQL/PostgreSQL (evita ENUM nativo, usa CHECK).
-- =========================================================
 
DROP TABLE IF EXISTS orden_repuestos;
DROP TABLE IF EXISTS ordenes_servicio;
DROP TABLE IF EXISTS vehiculos;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS repuestos;
DROP TABLE IF EXISTS usuarios;
 
-- ---------------------------------------------------------
-- USUARIOS: autenticación y roles del sistema
-- ---------------------------------------------------------
CREATE TABLE usuarios (
    id               BIGINT AUTO_INCREMENT PRIMARY KEY,
    username         VARCHAR(60)  NOT NULL UNIQUE,
    password         VARCHAR(255) NOT NULL,
    nombre_completo  VARCHAR(150) NOT NULL,
    role             VARCHAR(20)  NOT NULL DEFAULT 'RECEPCIONISTA'
                        CHECK (role IN ('ADMIN', 'RECEPCIONISTA')),
    estado           VARCHAR(20)  NOT NULL DEFAULT 'ACTIVO'
                        CHECK (estado IN ('ACTIVO', 'INACTIVO')),
    created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
 
-- ---------------------------------------------------------
-- CLIENTES
-- ---------------------------------------------------------
CREATE TABLE clientes (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(150) NOT NULL,
    documento   VARCHAR(30)  NOT NULL UNIQUE,
    telefono    VARCHAR(30),
    email       VARCHAR(120),
    direccion   VARCHAR(200),
    activo      BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
 
-- ---------------------------------------------------------
-- VEHICULOS: uno o varios por cliente
-- ---------------------------------------------------------
CREATE TABLE vehiculos (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id  BIGINT       NOT NULL,
    placa       VARCHAR(15)  NOT NULL UNIQUE,
    marca       VARCHAR(60)  NOT NULL,
    modelo      VARCHAR(60),
    anio        INT,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vehiculo_cliente FOREIGN KEY (cliente_id)
        REFERENCES clientes(id)
);
 
-- ---------------------------------------------------------
-- REPUESTOS: inventario
-- ---------------------------------------------------------
CREATE TABLE repuestos (
    id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
    codigo_referencia  VARCHAR(50)   NOT NULL UNIQUE,
    nombre             VARCHAR(150)  NOT NULL,
    categoria          VARCHAR(80),
    proveedor          VARCHAR(120),
    stock_total        INT           NOT NULL CHECK (stock_total >= 0),
    stock_disponible   INT           NOT NULL CHECK (stock_disponible >= 0),
    precio_unitario    DECIMAL(12,2) NOT NULL CHECK (precio_unitario >= 0),
    is_activo          BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
);
 
-- ---------------------------------------------------------
-- ORDENES_SERVICIO
-- ---------------------------------------------------------
CREATE TABLE ordenes_servicio (
    id                     BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id             BIGINT        NOT NULL,
    vehiculo_id            BIGINT        NOT NULL,
    mecanico_responsable   VARCHAR(150)  NOT NULL,
    fecha_ingreso          TIMESTAMP     NOT NULL,
    descripcion_problema   VARCHAR(500),
    diagnostico            VARCHAR(500),
    estado                 VARCHAR(30)   NOT NULL DEFAULT 'RECIBIDA'
                              CHECK (estado IN ('RECIBIDA', 'EN_DIAGNOSTICO',
                                                 'EN_REPARACION', 'FINALIZADA', 'ENTREGADA')),
    costo_total            DECIMAL(12,2) NOT NULL DEFAULT 0,
    created_at             TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_orden_cliente  FOREIGN KEY (cliente_id)  REFERENCES clientes(id),
    CONSTRAINT fk_orden_vehiculo FOREIGN KEY (vehiculo_id) REFERENCES vehiculos(id)
);
 
-- ---------------------------------------------------------
-- ORDEN_REPUESTOS: detalle de repuestos usados por orden
-- (necesaria para "repuestos utilizados" y el costo total)
-- ---------------------------------------------------------
CREATE TABLE orden_repuestos (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    orden_id          BIGINT        NOT NULL,
    repuesto_id       BIGINT        NOT NULL,
    cantidad          INT           NOT NULL CHECK (cantidad > 0),
    precio_unitario   DECIMAL(12,2) NOT NULL,
    CONSTRAINT fk_detalle_orden    FOREIGN KEY (orden_id)    REFERENCES ordenes_servicio(id),
    CONSTRAINT fk_detalle_repuesto FOREIGN KEY (repuesto_id) REFERENCES repuestos(id)
);